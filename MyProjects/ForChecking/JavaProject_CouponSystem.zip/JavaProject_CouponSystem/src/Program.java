import Test.Test;
/**
 * Program class, contains 'main' function, runs the entire system
 */
public class Program {
    public static void main(String[] args) {
        Test test = new Test();
        test.testAll();
    }
}