package Facade.LoginManager;

/**
 * Client type enum - used for Login manager
 */
public enum ClientType {
    Administrator,
    Company,
    Customer;
}
