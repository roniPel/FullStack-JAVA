package DataBase;

/**
 * Enum containing list of table names for inserting multiple values into DB.  Used to insert mock data into DB
 */
public enum SQLmultipleValues {
    Coupon, Company, Category, Customer, CustomerVsCoupon;
}
