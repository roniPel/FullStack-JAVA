package DataBase;

/**
 * Class used to configure connection details to DB - credentials, DB name, etc.
 */
public class DBmanager {
    //connection credentials to the Data Base
    public static final String URL = "jdbc:mysql://localhost:3306";
    public static final String SQL_USER = "root";
    public static final String SQL_PASSWORD = "12345678";

    //database name (schema)
    public static final String SQL_DB = "couponsystemdb";
}
